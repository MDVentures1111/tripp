"use client";

import { Link } from 'react-router-dom';
import { FileText } from 'lucide-react';

/** Document APIs require both organizationId and dealId; no organization-wide list exists. */
export const DocumentsView = () => (
  <div className="view-container tripp-workspace">
    <header><h1 className="view-title">Documents</h1><p className="view-subtitle">Documents are managed securely within individual deals.</p></header>
    <section className="tripp-workspace-card">
      <FileText size={28} aria-hidden="true" />
      <h2>Choose a deal</h2>
      <p>Open a deal to upload proposals and letters of intent, track security inspection, or download approved documents.</p>
      <Link className="tripp-deals-action" to="/workspace/deals">Browse deals</Link>
    </section>
  </div>
);
